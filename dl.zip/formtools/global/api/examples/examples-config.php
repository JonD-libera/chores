<?php

// you need to switch this to true to see the examples
$examples_enabled = false;

// these need to point to the API files on your server
$path_to_api_v1 = "../../../core/global/api/api.php";
$path_to_api_v2 = "../../../core/global/api/API.class.php";

// exit immediately if the examples aren't enabled
if (!$examples_enabled) {
    exit;
}
