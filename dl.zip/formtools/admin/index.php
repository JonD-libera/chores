<?php

// redirect to forms list page
session_write_close();
header("Location: ./forms/");
